"use client"

import { useState } from "react"
import { 
  User, 
  Building2, 
  Receipt, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  Loader2,
  Mail,
  Phone,
  MapPin,
  Home,
  Zap
} from "lucide-react"

type FormData = {
  // Step 1: Personal Info
  fullName: string
  email: string
  phone: string
  // Step 2: Property Details
  propertyType: string
  roofArea: string
  location: string
  // Step 3: Monthly Bill
  monthlyBill: string
  electricityProvider: string
  installationTimeline: string
}

const steps = [
  { id: 1, name: "Personal Info", icon: User },
  { id: 2, name: "Property Details", icon: Building2 },
  { id: 3, name: "Monthly Bill", icon: Receipt },
]

const initialFormData: FormData = {
  fullName: "",
  email: "",
  phone: "",
  propertyType: "",
  roofArea: "",
  location: "",
  monthlyBill: "",
  electricityProvider: "",
  installationTimeline: "",
}

export function EnquirySection() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const nextStep = () => {
    if (currentStep < 3) setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  const isStep1Valid = formData.fullName && formData.email && formData.phone
  const isStep2Valid = formData.propertyType && formData.roofArea && formData.location
  const isStep3Valid = formData.monthlyBill && formData.electricityProvider && formData.installationTimeline

  if (isSubmitted) {
    return (
      <section id="enquiry" className="py-24 lg:py-32 bg-background">
        <div className="mx-auto max-w-2xl px-6 text-center">
          <div className="w-24 h-24 mx-auto mb-8 rounded-full bg-primary/10 flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-primary" />
          </div>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
            Thank You!
          </h2>
          <p className="text-muted-foreground text-lg mb-2">
            Your savings calculation request has been submitted.
          </p>
          <p className="text-muted-foreground">
            Our solar experts will contact you within 24 hours with a detailed savings report.
          </p>
          <div className="mt-8 p-6 rounded-2xl bg-primary/5 border border-primary/20">
            <p className="text-sm text-muted-foreground mb-2">Estimated Annual Savings</p>
            <p className="text-4xl font-bold text-primary">Up to 90%</p>
            <p className="text-sm text-muted-foreground mt-2">on your electricity bills</p>
          </div>
          <button
            onClick={() => {
              setIsSubmitted(false)
              setCurrentStep(1)
              setFormData(initialFormData)
            }}
            className="mt-8 px-6 py-3 text-sm font-medium text-primary hover:underline"
          >
            Calculate Again
          </button>
        </div>
      </section>
    )
  }

  return (
    <section id="enquiry" className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-4xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-sm font-semibold text-primary mb-6">
            <Zap className="h-4 w-4" />
            Free Consultation
          </span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground tracking-tight">
            Calculate Your Savings
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
            Fill in your details and get a personalized solar savings estimate
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center flex-1">
                {/* Step Circle */}
                <div className="flex flex-col items-center">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                      currentStep >= step.id
                        ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {currentStep > step.id ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <step.icon className="w-5 h-5" />
                    )}
                  </div>
                  <span
                    className={`mt-2 text-sm font-medium hidden sm:block ${
                      currentStep >= step.id ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {step.name}
                  </span>
                </div>

                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="flex-1 mx-4">
                    <div className="h-1 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full bg-primary transition-all duration-500 ease-out"
                        style={{
                          width: currentStep > step.id ? "100%" : "0%",
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-card rounded-3xl p-8 md:p-12 shadow-2xl border border-border">
          <form onSubmit={handleSubmit}>
            {/* Step 1: Personal Info */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-card-foreground mb-2">Personal Information</h3>
                  <p className="text-muted-foreground">Let us know how to reach you</p>
                </div>

                <div className="space-y-6">
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-card-foreground mb-2">
                      <User className="inline h-4 w-4 mr-2 text-primary" />
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="fullName"
                      name="fullName"
                      required
                      value={formData.fullName}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-card-foreground mb-2">
                      <Mail className="inline h-4 w-4 mr-2 text-primary" />
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                      placeholder="your@email.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-card-foreground mb-2">
                      <Phone className="inline h-4 w-4 mr-2 text-primary" />
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                      placeholder="+91 98765 43210"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Property Details */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-card-foreground mb-2">Property Details</h3>
                  <p className="text-muted-foreground">Tell us about your property</p>
                </div>

                <div className="space-y-6">
                  <div>
                    <label htmlFor="propertyType" className="block text-sm font-medium text-card-foreground mb-2">
                      <Home className="inline h-4 w-4 mr-2 text-primary" />
                      Property Type *
                    </label>
                    <select
                      id="propertyType"
                      name="propertyType"
                      required
                      value={formData.propertyType}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    >
                      <option value="">Select property type</option>
                      <option value="residential">Residential Home</option>
                      <option value="apartment">Apartment / Flat</option>
                      <option value="commercial">Commercial Building</option>
                      <option value="industrial">Industrial Facility</option>
                      <option value="farm">Agricultural / Farm</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="roofArea" className="block text-sm font-medium text-card-foreground mb-2">
                      <Building2 className="inline h-4 w-4 mr-2 text-primary" />
                      Available Roof Area *
                    </label>
                    <select
                      id="roofArea"
                      name="roofArea"
                      required
                      value={formData.roofArea}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    >
                      <option value="">Select roof area</option>
                      <option value="100-200">100 - 200 sq ft</option>
                      <option value="200-500">200 - 500 sq ft</option>
                      <option value="500-1000">500 - 1000 sq ft</option>
                      <option value="1000-2000">1000 - 2000 sq ft</option>
                      <option value="2000+">2000+ sq ft</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-card-foreground mb-2">
                      <MapPin className="inline h-4 w-4 mr-2 text-primary" />
                      Location / City *
                    </label>
                    <input
                      type="text"
                      id="location"
                      name="location"
                      required
                      value={formData.location}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                      placeholder="Enter your city"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Monthly Bill */}
            {currentStep === 3 && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-card-foreground mb-2">Electricity Details</h3>
                  <p className="text-muted-foreground">Help us calculate your savings</p>
                </div>

                <div className="space-y-6">
                  <div>
                    <label htmlFor="monthlyBill" className="block text-sm font-medium text-card-foreground mb-2">
                      <Receipt className="inline h-4 w-4 mr-2 text-primary" />
                      Average Monthly Bill *
                    </label>
                    <select
                      id="monthlyBill"
                      name="monthlyBill"
                      required
                      value={formData.monthlyBill}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    >
                      <option value="">Select monthly bill range</option>
                      <option value="1000-3000">Rs 1,000 - Rs 3,000</option>
                      <option value="3000-5000">Rs 3,000 - Rs 5,000</option>
                      <option value="5000-10000">Rs 5,000 - Rs 10,000</option>
                      <option value="10000-20000">Rs 10,000 - Rs 20,000</option>
                      <option value="20000+">Rs 20,000+</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="electricityProvider" className="block text-sm font-medium text-card-foreground mb-2">
                      <Zap className="inline h-4 w-4 mr-2 text-primary" />
                      Electricity Provider *
                    </label>
                    <input
                      type="text"
                      id="electricityProvider"
                      name="electricityProvider"
                      required
                      value={formData.electricityProvider}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                      placeholder="e.g., BESCOM, TANGEDCO"
                    />
                  </div>

                  <div>
                    <label htmlFor="installationTimeline" className="block text-sm font-medium text-card-foreground mb-2">
                      Installation Timeline *
                    </label>
                    <select
                      id="installationTimeline"
                      name="installationTimeline"
                      required
                      value={formData.installationTimeline}
                      onChange={handleChange}
                      className="w-full px-4 py-4 rounded-xl bg-background border border-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    >
                      <option value="">When do you want to install?</option>
                      <option value="immediately">Immediately</option>
                      <option value="1-3months">Within 1-3 months</option>
                      <option value="3-6months">Within 3-6 months</option>
                      <option value="6months+">More than 6 months</option>
                      <option value="exploring">Just exploring options</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-10 pt-6 border-t border-border">
              {currentStep > 1 ? (
                <button
                  type="button"
                  onClick={prevStep}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl border border-border text-foreground font-medium hover:bg-muted transition-all"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Previous
                </button>
              ) : (
                <div />
              )}

              {currentStep < 3 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  disabled={
                    (currentStep === 1 && !isStep1Valid) ||
                    (currentStep === 2 && !isStep2Valid)
                  }
                  className="flex items-center gap-2 px-8 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-accent transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next Step
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={!isStep3Valid || isSubmitting}
                  className="flex items-center gap-2 px-8 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-accent transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-primary/30"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Calculating...
                    </>
                  ) : (
                    <>
                      Calculate Savings
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Trust Note */}
        <p className="text-center text-muted-foreground text-sm mt-8">
          Your information is secure and will only be used to provide you with a personalized quote.
        </p>
      </div>
    </section>
  )
}
