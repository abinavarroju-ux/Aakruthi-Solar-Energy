"use client"

import { Award, Building2, Home, Factory, MapPin, Headphones, ClipboardCheck, Smartphone } from "lucide-react"

const features = [
  {
    icon: MapPin,
    title: "Pan-India Presence",
    description: "Executing solar projects across residential, commercial, and industrial sectors nationwide.",
  },
  {
    icon: Headphones,
    title: "Proactive Support",
    description: "Reliable support and assistance available round the clock for peace of mind.",
  },
  {
    icon: ClipboardCheck,
    title: "Free Site Survey",
    description: "Free site inspection by experienced engineers for accurate solar planning.",
  },
  {
    icon: Smartphone,
    title: "Monitoring App",
    description: "Track complete solar performance in real time with our mobile app.",
  },
  {
    icon: Award,
    title: "Award Winner",
    description: "Recognized excellence in solar energy with prestigious industry awards.",
  },
  {
    icon: Building2,
    title: "100% Loan Facility",
    description: "Easy documentation and quick approval process for financing.",
  },
]

export function AboutSection() {
  return (
    <section id="about" className="relative py-24 lg:py-32 bg-background overflow-hidden">
      {/* Subtle background accent */}
      <div className="absolute top-0 right-0 w-1/3 h-96 bg-gradient-to-bl from-primary/5 to-transparent" />
      
      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl">
          <span className="text-sm font-semibold tracking-widest text-primary uppercase">
            About Us
          </span>
          <h2 className="mt-4 font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
            Your Trusted Solar Energy Partner
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Aakruthi Solar Energy is an authorized distributor of Truzon Solar, providing end-to-end solar energy solutions for residential, commercial, and industrial customers across India.
          </p>
        </div>

        {/* Two Column Layout */}
        <div className="mt-16 grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left: Services */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-foreground">Turnkey Solar EPC Solutions</h3>
            <p className="text-muted-foreground leading-relaxed">
              Our team handles everything from site survey and system design to installation, net metering, and government subsidy support. We provide customized solutions based on your energy needs.
            </p>
            
            {/* Service Types */}
            <div className="grid grid-cols-2 gap-3 pt-4">
              {[
                { icon: Home, label: "Residential" },
                { icon: Building2, label: "Commercial" },
                { icon: Factory, label: "Industrial" },
                { icon: MapPin, label: "Ground Mounted" },
              ].map((service) => (
                <div key={service.label} className="flex items-center gap-3 p-4 rounded-lg bg-muted/50 border border-border hover:border-primary/30 transition-colors">
                  <service.icon className="w-5 h-5 text-primary" />
                  <span className="font-medium text-foreground text-sm">{service.label}</span>
                </div>
              ))}
            </div>

            {/* Regional Presence */}
            <div className="pt-4">
              <p className="text-sm text-muted-foreground mb-3">Regional Presence:</p>
              <div className="flex flex-wrap gap-2">
                {["Telangana", "Andhra Pradesh", "Maharashtra", "Madhya Pradesh", "Chhattisgarh"].map((state) => (
                  <span key={state} className="px-3 py-1.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium">
                    {state}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Features Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group p-5 rounded-xl bg-card border border-border hover:border-primary/20 hover:shadow-md transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/15 transition-colors">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-sm font-semibold text-card-foreground mb-1">
                  {feature.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Partner Badge */}
        <div className="mt-20 pt-10 border-t border-border">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center sm:text-left">
            <p className="text-muted-foreground text-sm">Authorized Distributor of</p>
            <div className="flex items-center gap-2 px-5 py-2 rounded-lg bg-primary/10 border border-primary/20">
              <span className="text-lg font-bold text-primary tracking-tight">TRUZON SOLAR</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
