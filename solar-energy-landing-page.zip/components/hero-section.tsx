"use client"

import Link from "next/link"
import { ArrowRight, Calculator, Leaf, Zap, Battery } from "lucide-react"

export function HeroSection() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-secondary"
    >
      {/* Natural Glowing Sun Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        
        {/* Sun positioned in top-right area */}
        <div className="absolute -top-[200px] -right-[200px] md:-top-[300px] md:-right-[300px]">
          
          {/* Outermost glow - largest, most diffuse */}
          <div 
            className="w-[700px] h-[700px] md:w-[1000px] md:h-[1000px] rounded-full animate-sun-breathe"
            style={{
              background: 'radial-gradient(circle, rgba(245, 158, 11, 0.15) 0%, rgba(245, 158, 11, 0.05) 40%, transparent 70%)',
              filter: 'blur(40px)'
            }}
          />
          
          {/* Secondary warm glow */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] md:w-[700px] md:h-[700px] rounded-full animate-sun-pulse"
            style={{
              background: 'radial-gradient(circle, rgba(251, 191, 36, 0.25) 0%, rgba(245, 158, 11, 0.1) 50%, transparent 70%)',
              filter: 'blur(30px)'
            }}
          />
          
          {/* Rotating rays container */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] md:w-[800px] md:h-[800px] animate-sun-rotate">
            {[...Array(16)].map((_, i) => (
              <div
                key={i}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 origin-top"
                style={{ 
                  transform: `translate(-50%, 0) rotate(${i * 22.5}deg)`,
                  height: '50%'
                }}
              >
                <div 
                  className="w-[2px] h-full"
                  style={{
                    background: `linear-gradient(to bottom, rgba(245, 158, 11, ${i % 2 === 0 ? 0.3 : 0.15}) 0%, transparent 100%)`
                  }}
                />
              </div>
            ))}
          </div>
          
          {/* Inner corona - warmer orange */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] md:w-[450px] md:h-[450px] rounded-full animate-sun-core"
            style={{
              background: 'radial-gradient(circle, rgba(251, 191, 36, 0.4) 0%, rgba(245, 158, 11, 0.2) 50%, transparent 70%)',
              filter: 'blur(20px)'
            }}
          />
          
          {/* Core sun disc - brightest part */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[180px] h-[180px] md:w-[280px] md:h-[280px] rounded-full animate-sun-core"
            style={{
              background: 'radial-gradient(circle, rgba(253, 224, 71, 0.6) 0%, rgba(251, 191, 36, 0.4) 40%, rgba(245, 158, 11, 0.2) 70%, transparent 100%)',
              filter: 'blur(10px)',
              animationDelay: '0.5s'
            }}
          />
          
          {/* Bright hot center */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[100px] h-[100px] md:w-[150px] md:h-[150px] rounded-full animate-sun-breathe"
            style={{
              background: 'radial-gradient(circle, rgba(254, 243, 199, 0.8) 0%, rgba(253, 224, 71, 0.5) 50%, transparent 100%)',
              filter: 'blur(5px)',
              animationDelay: '1s'
            }}
          />
        </div>
        
        {/* Light particles floating */}
        <div className="absolute top-[15%] right-[20%] w-3 h-3 bg-amber-400/40 rounded-full blur-sm animate-particle-float" />
        <div className="absolute top-[25%] right-[30%] w-2 h-2 bg-yellow-300/30 rounded-full blur-sm animate-particle-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-[35%] right-[15%] w-2 h-2 bg-amber-300/25 rounded-full blur-sm animate-particle-float" style={{ animationDelay: '4s' }} />
        <div className="absolute top-[10%] right-[40%] w-1.5 h-1.5 bg-yellow-200/20 rounded-full blur-sm animate-particle-float" style={{ animationDelay: '3s' }} />
        <div className="absolute top-[45%] right-[25%] w-1.5 h-1.5 bg-amber-200/30 rounded-full blur-sm animate-particle-float" style={{ animationDelay: '5s' }} />
      </div>

      {/* Subtle ambient glow on left */}
      <div 
        className="absolute -bottom-[200px] -left-[200px] w-[500px] h-[500px] rounded-full blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(245, 158, 11, 0.08) 0%, transparent 70%)'
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8 py-32 md:py-40">
        <div className="flex flex-col items-center text-center">
          {/* Eco Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/20 bg-secondary-foreground/5 backdrop-blur-sm mb-8 animate-fade-in-up">
            <Leaf className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-secondary-foreground/90">
              Eco Friendly Solar Solutions
            </span>
          </div>

          {/* Main Heading */}
          <h1 className="font-serif text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-bold text-secondary-foreground tracking-tight max-w-5xl text-balance animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            Power Your Future With{" "}
            <span className="text-primary relative inline-block">
              Solar
              <svg className="absolute -bottom-1 md:-bottom-2 left-0 w-full h-2 md:h-3" viewBox="0 0 200 12" fill="none" preserveAspectRatio="none">
                <path d="M0 8C40 2 80 2 100 6C120 10 160 10 200 4" stroke="currentColor" strokeWidth="3" strokeLinecap="round" className="text-primary/40"/>
              </svg>
            </span>
          </h1>

          {/* Subtitle */}
          <p className="mt-6 md:mt-8 text-base md:text-xl text-secondary-foreground/70 max-w-2xl leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            Your trusted partner for complete solar EPC solutions. Residential, commercial & industrial solar installations across India.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mt-10 md:mt-12 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            <Link
              href="#enquiry"
              className="group inline-flex items-center justify-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-accent transition-all duration-300 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/35"
            >
              <Calculator className="h-5 w-5" />
              Calculate My Savings
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="#about"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 text-secondary-foreground font-semibold rounded-lg border border-secondary-foreground/20 hover:bg-secondary-foreground/5 transition-all duration-300"
            >
              Learn More
            </Link>
          </div>

          {/* Stats */}
          <div className="flex flex-col sm:flex-row gap-8 sm:gap-16 mt-16 md:mt-24 pt-10 md:pt-12 border-t border-secondary-foreground/10 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <div className="text-center group">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl md:text-6xl font-bold text-primary">500</span>
                <span className="text-2xl md:text-3xl font-bold text-primary">+</span>
              </div>
              <div className="mt-2 text-sm md:text-base text-secondary-foreground/60 flex items-center justify-center gap-2">
                <Zap className="w-4 h-4" />
                Projects Completed
              </div>
            </div>
            <div className="hidden sm:block w-px bg-secondary-foreground/10" />
            <div className="text-center group">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl md:text-6xl font-bold text-primary">2</span>
                <span className="text-2xl md:text-3xl font-bold text-primary">MW+</span>
              </div>
              <div className="mt-2 text-sm md:text-base text-secondary-foreground/60 flex items-center justify-center gap-2">
                <Battery className="w-4 h-4" />
                Power Served
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
        <span className="text-xs text-secondary-foreground/40 tracking-widest uppercase">
          Scroll
        </span>
        <div className="w-5 h-9 border border-secondary-foreground/20 rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-primary rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  )
}
