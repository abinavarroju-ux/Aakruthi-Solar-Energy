"use client"

import { Mail, MapPin, Phone, Clock, Sun } from "lucide-react"
import Link from "next/link"

const contactInfo = [
  {
    icon: Phone,
    label: "Call Us",
    value: "+91 9848003199",
    href: "tel:+919848003199",
  },
  {
    icon: Mail,
    label: "Email Us",
    value: "aakruthisolarenergy@gmail.com",
    href: "mailto:aakruthisolarenergy@gmail.com",
  },
  {
    icon: MapPin,
    label: "Visit Us",
    value: "Yana Towers, 15-97, Ambedkar Nagar, Opp Metro Pillar C909, Uppal Stadium, Hyderabad - 500068",
    href: "#",
  },
  {
    icon: Clock,
    label: "Business Hours",
    value: "Mon - Sat: 9:00 AM - 6:00 PM",
    href: "#",
  },
]

const quickLinks = [
  { name: "Home", href: "#home" },
  { name: "About Us", href: "#about" },
  { name: "Products", href: "#products" },
  { name: "Enquiry", href: "#enquiry" },
  { name: "Contact", href: "#contact" },
]

const services = [
  "Residential Rooftop Solar",
  "Commercial Solar Solutions",
  "Industrial Solar Projects",
  "Ground Mounted Solar",
  "Solar Water Heater",
  "Net Metering Support",
]

export function ContactSection() {
  return (
    <section id="contact" className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-sm font-semibold tracking-widest text-primary uppercase">
            Contact Us
          </span>
          <h2 className="mt-4 font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight">
            Get In Touch
          </h2>
          <p className="mt-4 text-muted-foreground">
            Ready to switch to solar? We are here to help.
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {contactInfo.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="group p-5 rounded-xl bg-card border border-border hover:border-primary/20 transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/15 transition-colors">
                <item.icon className="w-5 h-5 text-primary" />
              </div>
              <div className="text-xs text-muted-foreground mb-1">{item.label}</div>
              <div className="text-card-foreground font-medium text-sm">{item.value}</div>
            </a>
          ))}
        </div>

        {/* Map Placeholder */}
        <div className="relative h-64 rounded-2xl overflow-hidden bg-muted mb-16">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-10 h-10 text-primary mx-auto mb-3" />
              <p className="text-foreground font-medium text-sm">Uppal, Hyderabad</p>
              <p className="text-xs text-muted-foreground">Telangana, India</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export function Footer() {
  return (
    <footer className="bg-secondary py-14">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="#home" className="flex items-center gap-3 mb-5">
              <Sun className="h-8 w-8 text-primary" />
              <div className="flex flex-col">
                <span className="text-lg font-bold text-secondary-foreground">Aakruthi</span>
                <span className="text-[10px] font-semibold tracking-[0.2em] text-primary uppercase">Solar Energy</span>
              </div>
            </Link>
            <p className="text-secondary-foreground/60 text-sm leading-relaxed mb-5">
              Authorized Truzon Solar distributor providing complete solar EPC solutions across India.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-secondary-foreground tracking-wider uppercase mb-5">
              Quick Links
            </h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-secondary-foreground/60 hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-sm font-semibold text-secondary-foreground tracking-wider uppercase mb-5">
              Services
            </h3>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service}>
                  <span className="text-sm text-secondary-foreground/60">
                    {service}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-sm font-semibold text-secondary-foreground tracking-wider uppercase mb-5">
              Stay Updated
            </h3>
            <p className="text-sm text-secondary-foreground/60 mb-4">
              Subscribe for solar industry updates and offers.
            </p>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 px-4 py-2.5 rounded-lg bg-secondary-foreground/5 border border-secondary-foreground/10 text-secondary-foreground placeholder:text-secondary-foreground/40 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-accent transition-colors"
              >
                Join
              </button>
            </form>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-secondary-foreground/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-secondary-foreground/50">
            © {new Date().getFullYear()} Aakruthi Solar Energy. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link href="#" className="text-xs text-secondary-foreground/50 hover:text-primary transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="text-xs text-secondary-foreground/50 hover:text-primary transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
