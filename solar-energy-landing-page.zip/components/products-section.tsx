"use client"

import { Sun, Award, Wrench, Calculator, FileCheck, Zap, CheckCircle2, ArrowRight } from "lucide-react"

const services = [
  {
    name: "Site Survey",
    description: "Detailed site analysis by experienced engineers",
    icon: Calculator,
    step: 1,
  },
  {
    name: "Custom Design",
    description: "System design for maximum efficiency",
    icon: Wrench,
    step: 2,
  },
  {
    name: "Production",
    description: "Quality components for long-term performance",
    icon: Sun,
    step: 3,
  },
  {
    name: "Installation",
    description: "Safe installation by certified technicians",
    icon: Zap,
    step: 4,
  },
  {
    name: "Net Metering",
    description: "Complete grid connection support",
    icon: FileCheck,
    step: 5,
  },
  {
    name: "Subsidy Help",
    description: "PM Surya Ghar subsidy assistance",
    icon: Award,
    step: 6,
  },
]

const benefits = [
  "25-year performance warranty on panels",
  "Up to Rs 78,000 government subsidy",
  "1 kW system generates 4-5 units daily",
  "Minimal maintenance required",
  "100% loan facility available",
  "MNRE-approved components only",
]

export function ProductsSection() {
  return (
    <section id="products" className="py-24 lg:py-32 bg-secondary relative overflow-hidden grain">
      {/* Animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Floating orbs */}
        <div className="absolute top-20 right-[20%] w-64 h-64 bg-primary/10 rounded-full blur-[100px] animate-pulse-glow" />
        <div className="absolute bottom-40 left-[10%] w-48 h-48 bg-primary/10 rounded-full blur-[80px] animate-pulse-glow" style={{ animationDelay: '2s' }} />
        
        {/* Connecting lines animation */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="1" className="text-secondary-foreground"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-sm font-semibold tracking-widest text-primary uppercase">
            Our Process
          </span>
          <h2 className="mt-4 font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-secondary-foreground tracking-tight">
            End-to-End Solar Solutions
          </h2>
          <p className="mt-4 text-secondary-foreground/70 max-w-xl mx-auto">
            Complete turnkey solar EPC solutions from survey to subsidy
          </p>
        </div>

        {/* Services Timeline */}
        <div className="relative">
          {/* Connection line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent -translate-y-1/2" />
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-6">
            {services.map((service, index) => (
              <div
                key={service.name}
                className="relative group"
              >
                {/* Card */}
                <div className="relative bg-secondary-foreground/5 backdrop-blur-sm border border-secondary-foreground/10 rounded-xl p-5 transition-all duration-500 hover:bg-secondary-foreground/10 hover:border-primary/30 hover:-translate-y-1">
                  {/* Step number */}
                  <div className="absolute -top-3 left-4 bg-primary text-primary-foreground text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center shadow-md">
                    {service.step}
                  </div>

                  {/* Icon */}
                  <div className="w-11 h-11 rounded-lg bg-primary/15 flex items-center justify-center mb-4 group-hover:bg-primary/25 transition-colors">
                    <service.icon className="h-5 w-5 text-primary" />
                  </div>

                  {/* Content */}
                  <h3 className="text-sm font-semibold text-secondary-foreground mb-1">
                    {service.name}
                  </h3>
                  <p className="text-xs text-secondary-foreground/60 leading-relaxed">
                    {service.description}
                  </p>
                </div>

                {/* Arrow between cards (desktop only) */}
                {index < services.length - 1 && (
                  <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10">
                    <ArrowRight className="w-4 h-4 text-primary/40" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Benefits Section */}
        <div className="mt-20 bg-secondary-foreground/5 backdrop-blur-sm border border-secondary-foreground/10 rounded-2xl p-6 md:p-10">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-secondary-foreground mb-3">
                Why Choose Solar With Us?
              </h3>
              <p className="text-secondary-foreground/70 text-sm leading-relaxed">
                Using high-quality solar panels and advanced technology, we ensure maximum efficiency and long-term performance for every project.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              {benefits.map((benefit) => (
                <div key={benefit} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <span className="text-secondary-foreground text-sm">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Trust badges */}
        <div className="mt-14 pt-10 border-t border-secondary-foreground/10">
          <p className="text-center text-secondary-foreground/40 text-xs uppercase tracking-wider mb-5">Certifications & Approvals</p>
          <div className="flex flex-wrap justify-center gap-3">
            {["IEC 61215", "ISO 9001:2015", "BIS Certified", "MNRE Approved"].map((cert) => (
              <div key={cert} className="px-4 py-2 rounded-md bg-secondary-foreground/5 border border-secondary-foreground/10">
                <span className="text-secondary-foreground/70 font-medium text-xs">{cert}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
