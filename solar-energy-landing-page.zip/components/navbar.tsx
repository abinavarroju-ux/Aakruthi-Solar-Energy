"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X, Sun } from "lucide-react"

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Products", href: "#products" },
  { name: "Enquiry", href: "#enquiry" },
  { name: "Contact", href: "#contact" },
]

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-secondary/95 backdrop-blur-md shadow-lg shadow-black/5"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link href="#home" className="flex items-center gap-3 group">
            <div className="relative">
              <Sun className="h-9 w-9 text-primary transition-transform duration-700 group-hover:rotate-180" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-secondary-foreground">
                Aakruthi
              </span>
              <span className="text-[10px] font-semibold tracking-[0.2em] text-primary uppercase">
                Solar Energy
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="relative px-4 py-2 text-sm font-medium text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
              >
                {link.name}
              </Link>
            ))}
            <Link
              href="#enquiry"
              className="ml-4 px-5 py-2.5 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-accent transition-all duration-300"
            >
              Get Quote
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-secondary-foreground"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-300 ${
            isOpen ? "max-h-80 pb-6" : "max-h-0"
          }`}
        >
          <div className="flex flex-col gap-1 pt-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="px-4 py-3 text-secondary-foreground/70 hover:text-secondary-foreground hover:bg-secondary-foreground/5 rounded-lg transition-colors"
              >
                {link.name}
              </Link>
            ))}
            <Link
              href="#enquiry"
              onClick={() => setIsOpen(false)}
              className="mt-2 mx-4 px-6 py-3 bg-primary text-primary-foreground text-center font-semibold rounded-lg"
            >
              Get Quote
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
