import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ProductsSection } from "@/components/products-section"
import { EnquirySection } from "@/components/enquiry-section"
import { ContactSection, Footer } from "@/components/contact-section"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ProductsSection />
      <EnquirySection />
      <ContactSection />
      <Footer />
    </main>
  )
}
